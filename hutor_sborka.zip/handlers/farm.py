from aiogram import Router

router = Router()

# 🌾 Заготовка фермы HUTOR
