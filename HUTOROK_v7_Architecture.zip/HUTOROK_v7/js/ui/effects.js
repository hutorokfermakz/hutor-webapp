// effects.js
