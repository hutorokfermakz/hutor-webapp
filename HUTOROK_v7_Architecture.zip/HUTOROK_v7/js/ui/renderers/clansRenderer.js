// clansRenderer.js
