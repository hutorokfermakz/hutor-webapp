// inventoryRenderer.js
