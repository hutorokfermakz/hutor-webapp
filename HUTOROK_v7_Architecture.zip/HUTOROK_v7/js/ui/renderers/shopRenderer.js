// shopRenderer.js
