// clanChat.js
