// clansSystem.js
