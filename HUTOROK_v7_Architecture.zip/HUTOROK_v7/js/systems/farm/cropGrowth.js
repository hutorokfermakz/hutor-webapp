// cropGrowth.js
