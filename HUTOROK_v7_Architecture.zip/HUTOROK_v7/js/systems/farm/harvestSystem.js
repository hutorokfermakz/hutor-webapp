// harvestSystem.js
