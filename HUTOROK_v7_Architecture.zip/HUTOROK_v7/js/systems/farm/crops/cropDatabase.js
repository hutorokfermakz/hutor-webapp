// cropDatabase.js
