// offlineProgress.js
