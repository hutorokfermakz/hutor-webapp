// storageSystem.js
