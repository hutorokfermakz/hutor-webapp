// inventorySystem.js
