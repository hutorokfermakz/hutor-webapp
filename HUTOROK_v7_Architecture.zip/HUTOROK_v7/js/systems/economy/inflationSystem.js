// inflationSystem.js
