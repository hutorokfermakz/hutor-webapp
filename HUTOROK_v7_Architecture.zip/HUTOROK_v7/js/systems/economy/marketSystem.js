// marketSystem.js
