// translations.js
